-----------------------------------------------------------

Hi there, 

Firstly, I would like to thank you for downloading this file, if you like it share it around of-course, but please creadit Inspiration-Hut and link back to our website for downloading. Secondly, here's a few things that would hopefully help you when you come to edit this file. 

--------------------BACKGROUND COLORS----------------------


In both the dark and light versions, there are 4 different color backgrounds, but by default the Dark version's background is "darkgrey.jpg" and the Light version's background is "lightgrey.jpg", to change these backgrounds to one of the following - 

darkgreen.jpg
darkblue.jpg
darkbrown.jpg
lightgreen.jpg
lightblue.jpg
lightorange.jpg 

simply edit the below css line
 

body {
	background-image:url(images/NAME OF FILE HERE.jpg);
}

and click save. Done! 


-----------------------------------------------------------

----------------------CSS EXPLAINED------------------------

#socialbox = an invsible box that contains the social icons down the bottom of the layout, below the #box 

#socialicon = a holder div for the individual social icons that are contained within the social box

#box = the main container for all the content, the background of this is the main bulk of imagery aswell as the highlights, shadows and indenting. 

#typebox = the typebox is an invisible box which contains all of the text to the right of the 404 title.

#listone = is the left hand navigation menu 

#listtwo = is the right hand navigation menu 

#typebox ul = this is the styling for the unordered list's within the #typebox holder tags. 

#typebox li = this is the stylish for the list's within the #typebox holder tags. 

#searchbar = the holder for the searchbar down the bottom right of the template, this also has the indenting and break of the bar set as the background 

#searchbutton = the holder for the hover over search button that is contained within #searchbar

-----------------------------------------------------------

any more questions, get in touch.

thanks, 

Tom - Inspiration Hut


